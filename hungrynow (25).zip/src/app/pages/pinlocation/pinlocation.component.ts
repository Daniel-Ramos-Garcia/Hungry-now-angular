import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pinlocation',
  templateUrl: './pinlocation.component.html',
  styleUrls: ['./pinlocation.component.css']
})
export class PinlocationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
