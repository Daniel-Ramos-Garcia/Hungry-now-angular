import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-extrasizeselection',
  templateUrl: './extrasizeselection.component.html',
  styleUrls: ['./extrasizeselection.component.css']
})
export class ExtrasizeselectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
