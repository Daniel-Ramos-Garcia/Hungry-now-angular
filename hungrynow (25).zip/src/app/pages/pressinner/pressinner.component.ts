import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pressinner',
  templateUrl: './pressinner.component.html',
  styleUrls: ['./pressinner.component.css']
})
export class PressinnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
