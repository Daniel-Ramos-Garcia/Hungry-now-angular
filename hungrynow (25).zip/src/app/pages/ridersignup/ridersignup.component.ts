import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ridersignup',
  templateUrl: './ridersignup.component.html',
  styleUrls: ['./ridersignup.component.css']
})
export class RidersignupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
