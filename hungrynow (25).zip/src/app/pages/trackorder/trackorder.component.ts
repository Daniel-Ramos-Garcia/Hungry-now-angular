import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trackorder',
  templateUrl: './trackorder.component.html',
  styleUrls: ['./trackorder.component.css']
})
export class TrackorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
