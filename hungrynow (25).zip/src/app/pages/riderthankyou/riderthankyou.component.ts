import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-riderthankyou',
  templateUrl: './riderthankyou.component.html',
  styleUrls: ['./riderthankyou.component.css']
})
export class RiderthankyouComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
