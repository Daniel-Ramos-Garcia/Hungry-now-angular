import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchantstep4',
  templateUrl: './merchantstep4.component.html',
  styleUrls: ['./merchantstep4.component.css']
})
export class Merchantstep4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
