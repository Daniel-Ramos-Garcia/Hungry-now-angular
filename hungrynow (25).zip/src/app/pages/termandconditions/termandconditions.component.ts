import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termandconditions',
  templateUrl: './termandconditions.component.html',
  styleUrls: ['./termandconditions.component.css']
})
export class TermandconditionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
