import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-singlereward',
  templateUrl: './singlereward.component.html',
  styleUrls: ['./singlereward.component.css']
})
export class SinglerewardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
