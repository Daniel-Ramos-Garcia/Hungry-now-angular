import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ridersignupprocess',
  templateUrl: './ridersignupprocess.component.html',
  styleUrls: ['./ridersignupprocess.component.css']
})
export class RidersignupprocessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
