import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-underreviewapplication',
  templateUrl: './underreviewapplication.component.html',
  styleUrls: ['./underreviewapplication.component.css']
})
export class UnderreviewapplicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
