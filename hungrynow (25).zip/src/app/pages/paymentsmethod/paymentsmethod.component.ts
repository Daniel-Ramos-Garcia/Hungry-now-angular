import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentsmethod',
  templateUrl: './paymentsmethod.component.html',
  styleUrls: ['./paymentsmethod.component.css']
})
export class PaymentsmethodComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
