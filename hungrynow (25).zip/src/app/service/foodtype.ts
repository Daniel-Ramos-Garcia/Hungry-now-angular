export class Foodtype {
    icon: string;
    name: string;
    constructor(icon: string, name: string) {
        this.icon = icon;
        this.name = name;
    }
}
