import { Foodtype } from './foodtype';

describe('Foodtype', () => {
  it('should create an instance', () => {
    expect(new Foodtype()).toBeTruthy();
  });
});
