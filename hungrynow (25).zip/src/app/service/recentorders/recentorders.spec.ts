import { Recentorders } from './recentorders';

describe('Recentorders', () => {
  it('should create an instance', () => {
    expect(new Recentorders()).toBeTruthy();
  });
});
