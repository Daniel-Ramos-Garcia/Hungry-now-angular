import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profileshort',
  templateUrl: './profileshort.component.html',
  styleUrls: ['./profileshort.component.css']
})
export class ProfileshortComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
